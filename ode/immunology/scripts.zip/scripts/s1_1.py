print sum(range(1, 1001))
